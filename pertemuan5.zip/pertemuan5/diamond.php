<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan Soal Algoritma Bahasa Php</title>
    <style>
        body    {text-align: center; font-family: "Trebuchet MS", serif; background-color: black; color: white;}
        h1,h1   {margin-bottom: 0;}
        hr      {width: 80%;}
        form    {margin-top: 2rem;}
        pre     {margin-top: 1.4rem;}
        .result {
            margin: 1rem auto;
            padding: 0.25rem 0.25rem 1rem 0.25rem;
            background-color: black;
            width: 50%;
        }

    </style>
</head>
<body>
    <h1>Kode Program Php - Diamond X</h1>
    <hr>
    <form action="" method="POST">
        <div>
            lebar diamond: <input type="text" name="besar_diamond">
            <input type="submit" name="submit">
        </div>
    </form>
    <?php
    if (isset($_POST['submit'])) {
        $besar_diamond = $_POST['besar_diamond'];

        echo "<div class='result'>";
        echo "<h2>Hasil Kode Program</h2>";
        echo "<span>(lebar diamond: $besar_diamond)</span>";
        echo "<pre>";

        for ($i = 1; $i <= $besar_diamond; $i++) {
            for ($j = $besar_diamond; $j > $i; $j--) {
                echo "";
            }
            for ($k = 1; $k <= 1 * $i - 1; $k++) {
                echo "X";
            }
            echo "\n";
        }
    
        // Bagian bawah berlian
        for ($i = $besar_diamond - 1; $i >= 1; $i--) {
            for ($j = $besar_diamond; $j > $i; $j--) {
                echo "";
            }
            for ($k = 1; $k <= 1 * $i - 1; $k++) {
                echo "X";
            }
            echo "\n";
        }
    
        echo "<pre>";
        echo "</div>";
    }
    ?>
</body>
</html>