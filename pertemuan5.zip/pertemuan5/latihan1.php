<?php 

function salam(){
    echo "<p>Selamat pagi</p>";
}

salam(); // Selamat Pagi

?>